
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h2>function availablehotelroom()</h2>
  <p>Route::get('report/availablehotelrooms', [HotelController::class, 'availablehotelroom']);</p>
  <table class="table">
    <thead>
      <tr>
        <th>name</th>
        <th>city</th>
        <th>Kamar Tersedia</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $queryModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($data ->name); ?></td>
        <td><?php echo e($data ->city); ?></td>
        <td><?php echo e($data->kamar_tersedia); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\WFP\laravel10\resources\views/hotel/available_room.blade.php ENDPATH**/ ?>