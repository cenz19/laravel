<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    /* Global styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: Arial, sans-serif;
    }

    /* Main container */
    .container {
      max-width: 1100px;
      padding: 20px;
      margin: 100px auto;
    }

    /* Header section */
    .header {
      color: #007bff;
    }

    .header-title {
      font-weight: bolder;
    }

    /* Button styles */
    a {
      color: white;
      text-decoration: none; /* Remove underline */
    }

    button {
      padding: 10px 20px; 
      width: 100%;
      font-size: 16px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 10px;
      cursor: pointer;
    }

    button:hover {
      background-color: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container">
    <header>
      <h1 class="header">Hello, <?php echo e($name[0]); ?></h1>
      <h2 class="header-title">Welcome to our website</h2>
      <a href="<?php echo e(url('/kategori')); ?>"><button>Choose Bed</button></a>
      <a href="<?php echo e(url('/product')); ?>"><button>See Product</button></a>
      <a href="<?php echo e(url('/hotel')); ?>"><button>See Hotel</button></a>
    </header>
    <form action="" method="POST">
      <?php echo method_field('PUT'); ?>
      <?php echo csrf_field(); ?>
    </form>
  </div>
</body>



      
<?php /**PATH C:\xampp\htdocs\WFP\laravel10\resources\views/dashboard.blade.php ENDPATH**/ ?>