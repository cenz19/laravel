<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('hotels', function (Blueprint $table) {
            //
            $table->string('name',100);
            $table->string('address',100);
            $table->integer('postcode');
            $table->string('city',100);
            $table->string('state',100);
            $table->integer('country_id');
            $table->double('longitude');
            $table->double('latitude');
            $table->Integer('phone');
            $table->string('fax');
            $table->string('email');
            $table->string('currency');
            $table->string('accomodation_type');
            $table->string('category');
            $table->string('web');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('hotels', function (Blueprint $table) {
            //
            $table->dropColumns('name');
            $table->dropColumns('address');
            $table->dropColumns('postcode');
            $table->dropColumns('city');
            $table->dropColumns('state');
            $table->dropColumns('country_id');
            $table->dropColumns('longitude');
            $table->dropColumns('latitude');
            $table->dropColumns('phone');
            $table->dropColumns('fax');
            $table->dropColumns('email');
            $table->dropColumns('currency');
            $table->dropColumns('accomodation_type');
            $table->dropColumns('accomodation_type');
            $table->dropColumns('category');
            $table->dropColumns('web');
        });
    }
};
