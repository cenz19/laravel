<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class HotelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $hotelNames = ['Hilton Hotel', 'Marriott Hotel', 'Sheraton Hotel', 'Hyatt Regency', 'Radisson Blu'];
        
        foreach ($hotelNames as $hotelName) {
            $address = rand(100, 999) . ' ' . ucwords(strtolower($hotelName)) . ' Street';
            DB::table('hotels')->insert([
                [
                    'name' => $hotelName,
                    'address' => $address,
                    'postcode' => random_int(1000,10000),
                    'city' => Str::random(10),
                    'state' => 'NY',
                    'country_id' => 1,
                    'longitude' => -74.005972,
                    'latitude' => 40.712776,
                    'phone' => 123,
                    'fax' => '987-654-3210',
                    'email' => 'info@' . strtolower(str_replace(' ', '', $hotelName)) . '.com',
                    'currency' => 'USD',
                    'accomodation_type' => 'Hotel',
                    'category' => '5 Stars',
                    'web' => 'https://www.' . strtolower(str_replace(' ', '', $hotelName)) . '.com',
                    'type_id' => random_int(1,3),
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ]);
        }    
    }
}
