<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        
        $names = ['John Doe', 'Jane Smith', 'Michael Johnson', 'Emily Brown', 'David Wilson'];
        
        foreach($names as $name) {
            DB::table('users')->insert([
                [
                    'name' => $name,
                    'email' => Str::random(10).'@gmail.com',
                    'password' => bcrypt('password'), // you can customize the password if needed
                    'created_at' => now(),
                    'updated_at' => now(),
                ],
            ]);
        }
    }
}

