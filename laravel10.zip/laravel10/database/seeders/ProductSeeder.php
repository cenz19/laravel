<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        //
        $productNames = [
            'Room Service',
            'Mini Bar',
            'Toiletries',
            'Towels',
            'Bathrobes',
            'Slippers',
            'Laundry Service',
            'WiFi Access',
            'Parking Service',
            'Swimming Pool Access',
            'Gym Access',
            'Spa Treatment',
            'Restaurant',
            'Bar',
            'Coffee Shop',
            'Gift Shop',
            'Concierge Service',
            'Airport Shuttle Service',
            'Tour Packages',
            'Conference Room Rental',
            // Add more product names as needed
        ];
        foreach($productNames as $productName){
            DB::table('products')->insert([
                [
                    'created_at' => now(),
                    'updated_at' => now(),
                    'name' => $productName,
                    'price' => rand(1000,10000),
                    'hotel_id' => rand(1,5),
                    'available_room' => rand(1,10)// you can customize the password if needed
                ],
            ]);
        }

    }
}
